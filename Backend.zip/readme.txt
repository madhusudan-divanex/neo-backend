/lab/staff
/lab/staff/:id
/lab/staff-data/:id
/lab/staff/:id
/lab/professional
/lab/employment
/lab/access
/lab/image
/appointment/lab/:id

Patient->
    Lab Report
    Favorite
    Chat 
Pharmacy->
    Chat 
Laboratory->
    Chat
Laboratory Api ->
    Get Appointment for lab 
    Add/Get Staff
    Staff employment
    Staff professional
    Staff access 
    Lab images

Doctor->
    Appointment Detail 
    Add/Edit/Delete Prescription 
    Active/Inacitve Prescription 
    Past Appointment 
    Downlaod Prescription
    Prescriptions
    Patient Detail 
    Add Lab Test
    
Patient->
    Downlaod Prescription
    
Admin->
    npm i 
    npm run dev 
Frontend->
    npm i --force 
    npm run start 
Backend->
    npm i 
    npx nodemon

Paitent->
    Change password
    Get Lab Appointment 
    Get Lab test Report 
    Neo Health Card
    Edit Request 
    Update Profile 
    Downlaod Health Card

Pending 
Cancel 
visited
pending-report
     
    Verify Otp 
    Kyc 
    Personal & Demographic Data 
    Medical History 
    Family History 
    Prescription And Reports
    CRD Sell
Pharmacy->
    Manual Sell 
    Generate Bill 

Wizbizla->     
    FeedBack (Notification)
Hospital->
    CRUD Patient 

https://neohospital.divanex.in/
madhu13@gmail.com
123456

https://noepatient.divanex.in/
4532656243
1234

Hospital->
    CRUD Permission 
    Doctor employment & access
Laboratory->
    Notification 
    Note option
Patient->
    Notification
    Pharmacy 
Doctor->
    Reminder

    Add Appointment
    CRUD Return 
    CRUD Purchase Order
    Signup,Upload Image,contact person 
    license ,Addresss
    edit request
    change password 
    profile

    public->components->auth->login.jsx

Admin->
    Advertisment (select provider) only on home page accerdian 
    Home page description (text editor)

    Staff 
    Lab 
    Pharmacy 
    Doctor 
    
Api->
    Test Report
    Get Appointment Data
    Get Test Report
    
chart implemention done 

history data pending 

make a google sheet for Laboratory panel what this done in the project which i share to client 
 lab can create account -> Lab Images ->lab Addresss -> Contact Person ->Lab license and certificate 
 change password,forgot password
 user can send edit profile request to admin and after gettting permission user can edit this data (account -> Lab Images ->lab Addresss -> Contact Person ->Lab license and certificate )
 user can add Laboratory permission 
 user can create staff for the Laboratory and grant them permission 
 appointment request were show and user can approve and reject the appointment request 
 user can view patient details 
 user can add test in their Laboratory 
 user add test report the the appointment and generate invoice
